-- pg_trgm powers the CJK substring search that replaces SQLite's fts5+trigram
-- (notes_fts). ILIKE '%…%' uses the GIN gin_trgm_ops index without any extra
-- setup on the application side.
CREATE EXTENSION IF NOT EXISTS pg_trgm;
