#!/bin/sh
# Creates (or updates) industry_db_ro: the login every machine other than the
# DB host uses — e.g. psql on another machine and the read-only MCP container.
# It can only SELECT, so leaked client credentials cannot change the graph;
# the owner ($POSTGRES_USER) stays on the DB host for the routine tasks that
# write.
#
# Runs automatically on a fresh database (docker-entrypoint-initdb.d). On an
# existing one, and after changing POSTGRES_RO_PASSWORD, run it by hand — it
# is idempotent:
#
#     docker compose exec postgres sh /docker-entrypoint-initdb.d/02_readonly_role.sh
#
# On an Ubuntu host installed from the kb-* packages, kb-db-setup runs it as
# the postgres superuser, with PSQL_USER=postgres.
set -eu

: "${POSTGRES_RO_PASSWORD:?POSTGRES_RO_PASSWORD is not set in the container; add it to .env and run docker compose up -d}"

# The password travels as a psql variable (:'ro_password' quotes it), so no
# character in it can break out of the SQL.
psql -v ON_ERROR_STOP=1 -q \
  --username "${PSQL_USER:-$POSTGRES_USER}" --dbname "$POSTGRES_DB" \
  -v ro_password="$POSTGRES_RO_PASSWORD" \
  -v owner="$POSTGRES_USER" -v dbname="$POSTGRES_DB" <<'SQL'
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'industry_db_ro') THEN
    CREATE ROLE industry_db_ro LOGIN;
  END IF;
END
$$;
ALTER ROLE industry_db_ro PASSWORD :'ro_password';
-- A second guard on top of the missing privileges.
ALTER ROLE industry_db_ro SET default_transaction_read_only = on;

GRANT CONNECT ON DATABASE :"dbname" TO industry_db_ro;
GRANT USAGE ON SCHEMA public TO industry_db_ro;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO industry_db_ro;
-- Tables research-links creates later (schema.go's CREATE TABLE IF NOT
-- EXISTS) become readable without rerunning this script.
ALTER DEFAULT PRIVILEGES FOR ROLE :"owner" IN SCHEMA public
  GRANT SELECT ON TABLES TO industry_db_ro;
SQL
echo "industry_db_ro: ready"
